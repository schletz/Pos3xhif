﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ViewModelDemoApp.ViewModels;

namespace ViewModelDemoApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public enum State { Unfiltered = 1, Filtered = 2 }

    public partial class MainWindow : Window
    {
        // STATE MANAGEMENT
        private State currentState = State.Unfiltered;
        public State CurrentState
        {
            get => currentState;
            // Macht alle Aktionen, die beim Ändern des States notwendig sind.
            set
            {
                // VM holen
                MainViewModel vm = DataContext as MainViewModel;
                // Es soll gefiltert werden? Dann den Button umbenennen und
                // die Suche durchführen.
                if (value == State.Filtered)
                {
                    Suchbutton.Content = "Filter entfernen";
                    vm.Search(Suchname.Text);
                    // Wenn nichts gefunden wird, wird eine Collection mit einer Person,
                    // die null ist geliefert (DefaultIfEmpty).
                    // Daher zählen wir Personen, die nicht null sind.
                    Status.Text = $"{vm.Persons.Count(p => p != null)} Personen gefunden";
                }
                // Alles machen, wenn der Filter entfernt werden soll.
                if (value == State.Unfiltered)
                {
                    // Wenn wir das Textfeld im Code behind setzen,
                    // dann wird das Binding im VM nicht aktualisiert.
                    // Wir setzen daher beides.
                    Suchname.Text = "";
                    Status.Text = "";
                    Suchbutton.Content = "Suche";
                    // Die Suche mit leerem Suchbegriff liefert alle Ergebnisse.
                    vm.Search("");
                }
                currentState = value;
            }
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Eventhandler für den Suchbutton. Dieser setzt den State auf Filtered.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Suchbutton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentState == State.Unfiltered)
                CurrentState = State.Filtered;
            else
                CurrentState = State.Unfiltered;
        }

        private void PrevButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is MainViewModel vm) { vm.PrevPerson(); }
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is MainViewModel vm) { vm.NextPerson(); }
        }
    }
}
