﻿namespace EfCoreInheritance.Application.Model;

public class Course
{
    // TODO: Add your implementation
}

