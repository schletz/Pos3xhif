﻿namespace EfCoreInheritance.Application.Model;

public class Address
{
    // TODO: Add your implementation
}

