﻿namespace EfCoreInheritance.Application.Model;

public class PhoneNumber
{
    // TODO: Add your implementation
}

