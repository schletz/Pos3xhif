﻿namespace EfCoreInheritance.Application.Model;

public class Student : Person
{
    // TODO: Add your implementation
}

