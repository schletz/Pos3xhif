﻿namespace EfCoreInheritance.Application.Model;

public class Enrollment
{
    // TODO: Add your implementation
}

