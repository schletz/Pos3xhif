﻿namespace EfCoreInheritance.Application.Model;

public class Instructor : Person
{
    // TODO: Add your implementation
}

