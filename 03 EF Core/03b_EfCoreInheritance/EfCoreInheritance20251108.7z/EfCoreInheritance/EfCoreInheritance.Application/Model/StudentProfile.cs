﻿namespace EfCoreInheritance.Application.Model;

public class StudentProfile
{
    // TODO: Add your implementation
}

