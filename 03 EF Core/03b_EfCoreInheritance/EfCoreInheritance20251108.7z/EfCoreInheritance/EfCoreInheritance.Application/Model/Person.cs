﻿namespace EfCoreInheritance.Application.Model;

public abstract class Person
{
    // TODO: Add your implementation
}

