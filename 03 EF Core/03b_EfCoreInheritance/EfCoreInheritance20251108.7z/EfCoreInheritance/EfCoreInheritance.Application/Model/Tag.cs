﻿namespace EfCoreInheritance.Application.Model;

public class Tag
{
    // TODO: Add your implementation
}

