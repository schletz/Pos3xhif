﻿using System;
using System.Collections.Generic;

namespace Fitnesscenter.Application.Dtos;

public record ActiveMemberDto(int Id, string FirstName, string LastName, string Email);
public record TrainingSessionWithCountDto(
    int Id, string RoomName, DateTime DateTime,
    string TrainerFirstName, string TrainerLastName, int ParticipantCount);
public record MaxRatingCountPerTrainer(int Id, string FirstName, string LastName, int MaxRatingCount);
public record MemberWithVisitsDto(int Id, string FirstName, string LastName, string Email, List<VisitDto> Visits);
public record VisitDto(DateTime Start, DateTime? End);
