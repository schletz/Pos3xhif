﻿using Microsoft.EntityFrameworkCore;
using Fitnesscenter.Infrastructure;
using Fitnesscenter.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using Fitnesscenter.Application.Dtos;

namespace Fitnesscenter.Services;

public class FitnessService
{
    private readonly FitnessContext _db;
    public FitnessService(FitnessContext db)
    {
        _db = db;
    }

    public List<ActiveMemberDto> GetActiveMembers()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    public List<TrainingSessionWithCountDto> GetTrainingSessionsWithParticipantCounts()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    public MemberWithVisitsDto? GetMemberWithVisits(int memberId)
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    public List<Member> GetMembersWithoutParticipation()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    public List<MaxRatingCountPerTrainer> GetMaxRatingCountPerTrainer()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    public Participation RegisterMemberToTrainingSession(int memberId, int trainingSessionId)
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    public void UpdateRating(int memberId, int trainingSessionId, int rating)
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }
}
