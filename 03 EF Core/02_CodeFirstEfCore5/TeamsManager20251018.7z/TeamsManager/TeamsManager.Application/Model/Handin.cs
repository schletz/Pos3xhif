﻿using System;

namespace TeamsManager.Application.Model;

public class Handin
{
    // TODO: Füge hier deine Implementierung ein.
}
