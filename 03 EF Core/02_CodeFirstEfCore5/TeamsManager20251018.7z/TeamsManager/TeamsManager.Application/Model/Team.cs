﻿using Microsoft.EntityFrameworkCore;
using System;

namespace TeamsManager.Application.Model;

public class Team
{
    // TODO: Füge hier deine Implementierung ein.
}

