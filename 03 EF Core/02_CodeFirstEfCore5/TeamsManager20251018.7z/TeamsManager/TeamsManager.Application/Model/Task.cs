﻿using System;

namespace TeamsManager.Application.Model;

public class Task
{
    // TODO: Füge hier deine Implementierung ein.
}

