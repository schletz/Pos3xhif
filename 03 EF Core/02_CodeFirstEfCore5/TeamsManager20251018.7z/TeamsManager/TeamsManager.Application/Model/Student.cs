﻿namespace TeamsManager.Application.Model;

public class Student
{
    // TODO: Füge hier deine Implementierung ein.
}

