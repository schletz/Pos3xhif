﻿namespace TeamsManager.Application.Model;

public class Teacher
{
    // TODO: Füge hier deine Implementierung ein.
}
