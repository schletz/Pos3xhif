﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Plf5aaif.Application.Infrastructure;
using System;
using System.Diagnostics;

namespace Plf5aaif.Test;

public class JobApplicationContextTests
{
    private JobApplicationContext GetDatabase()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();

        var opt = new DbContextOptionsBuilder()
            .UseSqlite(connection)  // Keep connection open (only needed with SQLite in memory db)
            //.UseSqlServer("Server=127.0.0.1;Database=JobApplication;User Id=sa;Password=SqlServer2019;TrustServerCertificate=true")
            .LogTo(message => Debug.WriteLine(message), Microsoft.Extensions.Logging.LogLevel.Information)
            .EnableSensitiveDataLogging()
            .Options;
        var db = new JobApplicationContext(opt);
        Debug.WriteLine(db.Database.GenerateCreateScript());
        db.Database.EnsureDeleted();
        db.Database.EnsureCreated();
        return db;
    }

    [Fact]
    public void T00_CreateDatabaseSuccessTest()
    {
        using var db = GetDatabase();
        Assert.True(db.Database.CanConnect());
    }

    [Fact]
    public void T01_InsertJobPostingWithApplicationInterviewTest()
    {
        throw new NotImplementedException();
    }
    [Fact]
    public void T02_JobApplicationCandidateAndJobPostintIsUniqueTest()
    {
        throw new NotImplementedException();
    }
    [Fact]
    public void T03_AddDepartmentWithOfficeLocations()
    {
        throw new NotImplementedException();
    }
    [Fact]
    public void T04_SalaryRangeThrowsExceptionWhenMinMaxIsInvalidTest()
    {
        throw new NotImplementedException();
    }
}