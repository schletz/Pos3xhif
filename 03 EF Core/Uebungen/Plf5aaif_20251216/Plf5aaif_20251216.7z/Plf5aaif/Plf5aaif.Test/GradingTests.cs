﻿// *************************************************************************************************
// Grading tests for example.
// DO NOT TOUCH
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Plf5aaif.Application.Infrastructure;
using Plf5aaif.Application.Model;
using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;

namespace Plf5aaif.Test;

public class GradingTests
{
    [Fact]
    public void T00_CanCreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
        string createScript = db.Database.GenerateCreateScript();
        Debug.Write(createScript);

        using var command = db.Database.GetDbConnection().CreateCommand();
        command.CommandText = $"SELECT COUNT(*) FROM sqlite_master WHERE type='table';";
        db.Database.OpenConnection();
        var result = (long?)command.ExecuteScalar();
        Assert.True(result >= 3, $"Less than 3 tables found. Check your DbSets & mappings.");
    }

    [Fact]
    public void T00_SchemaTest() => InsertRow(
        "INSERT INTO Department(Name) VALUES ('IT');",
        "INSERT INTO OfficeLocation(Building, Room, DepartmentId) VALUES ('Spengergasse', 'C3.02', 1);",
        "INSERT INTO Person (Firstname, Lastname, PersonType, EmployeeNumber, HireDate, Workload, DepartmentId) VALUES ('first', 'last', 'Employee', '2024-09-20', '2024/142', 80, 1);",
        "INSERT INTO Person (Firstname, Lastname, PersonType, Email, LinkedInProfileUrl) VALUES ('first', 'last', 'Candidate', 'x@y.at', null);",
        "INSERT INTO JobPosting(Title, Description, DepartmentId, SalaryRange_Min, SalaryRange_Max) VALUES ('Cybersecurity', 'Desc', 1, 50000, 60000);",
        "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (2, 1, '2025-12-06T14:00:00Z');",
        "INSERT INTO ApplicationInterview(JobApplicationId, InterviewDate, InterviewerId, Rating, Notes) VALUES (1, '2025-12-14T15:00:00Z', 1, NULL, NULL);");


    // MODEL TESTS
    [Fact]
    public void T01_InsertDepartmentTest() => InsertRow(
        "INSERT INTO Department(Name) VALUES ('IT');");
    [Fact]
    public void T02_InsertPersonTest() => InsertRow(
        "INSERT INTO Person (Firstname, Lastname, PersonType) VALUES ('first', 'last', 'Employee');");
    [Fact]
    public void T03_InsertEmployeeTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Person (Firstname, Lastname, PersonType, EmployeeNumber, HireDate, Workload, DepartmentId) VALUES ('first', 'last', 'Employee', '2024-09-20', '2024/142', 80, 1);");
    [Fact]
    public void T04_InsertCandidateTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Person (Firstname, Lastname, PersonType, Email, LinkedInProfileUrl) VALUES ('first', 'last', 'Candidate', 'x@y.at', null);");
    [Fact]
    public void T05_InsertJobPostingTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO JobPosting(Title, Description, DepartmentId, SalaryRange_Min, SalaryRange_Max) VALUES ('Cybersecurity', 'Desc', 1, 50000, 60000);");
    [Fact]
    public void T06_InsertJobApplicationTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (2, 1, '2025-12-06T14:00:00Z');");
    [Fact]
    public void T07_InsertApplicationInterviewTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO ApplicationInterview(JobApplicationId, InterviewDate, InterviewerId, Rating, Notes) VALUES (1, '2025-12-14T15:00:00Z', 1, NULL, NULL);");

    // 1:1 TESTS
    [Fact]
    public void T08_JobApplicationAndApplicationInverviewIsOneToOneTest()
    {
        using var db = GetEmptyDbContext();
        var principalEntity = db.Model.GetEntityByClassname("JobApplication");
        var dependentEntity = db.Model.GetEntityByClassname("ApplicationInterview");
        var fk = dependentEntity.FindDeclaredNavigation("JobApplication")?.ForeignKey;
        Assert.NotNull(fk);
        Assert.True(fk.IsUnique);
        Assert.True(fk.DeclaringEntityType == dependentEntity);
        Assert.True(fk.PrincipalEntityType == principalEntity);
    }

    // UNIQUE CONSTRAINT TESTS
    [Fact]
    public void T09_EmployeeNumberIsUniqueTest()
    {
        InsertRow(foreignKeyCheck: false,
            "INSERT INTO Person (Firstname, Lastname, PersonType, EmployeeNumber, HireDate, Workload, DepartmentId) VALUES ('first', 'last', 'Employee', '2024-09-20', '2024/142', 80, 1);");
        InsertRowShouldFail(foreignKeyCheck: false,
            "INSERT INTO Person (Firstname, Lastname, PersonType, EmployeeNumber, HireDate, Workload, DepartmentId) VALUES ('first', 'last', 'Employee', '2024-09-20', '2024/142', 80, 1);",
            "INSERT INTO Person (Firstname, Lastname, PersonType, EmployeeNumber, HireDate, Workload, DepartmentId) VALUES ('first', 'last', 'Employee', '2024-09-20', '2024/142', 80, 1);");
    }

    [Fact]
    public void T10_JobApplicationCandidateAndJobPostingIsUniqueTest()
    {
        InsertRow(foreignKeyCheck: false,
            "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (1, 1, '2025-12-06T14:00:00Z');",
            "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (2, 1, '2025-12-07T14:00:00Z');",
            "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (1, 2, '2025-12-08T14:00:00Z');");
        InsertRowShouldFail(foreignKeyCheck: false,
            "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (1, 1, '2025-12-09T14:00:00Z');",
            "INSERT INTO JobApplication(CandidateId, JobPostingId, AppliedAt) VALUES (1, 1, '2025-12-10T14:00:00Z');");
    }

    // VALUE OBJECT AND RICH TYPE TESTS
    [Fact]
    public void T11_JobPosingSalaryRangeIsValueObjectTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(db.Model.GetEntityByClassname("SalaryRange").IsInOwnershipPath(db.Model.GetEntityByClassname("JobPosting")));
    }
    [Fact]
    public void T12_DepartmentOfficeLocationsIsValueObjectTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(db.Model.GetEntityByClassname("OfficeLocation").IsInOwnershipPath(db.Model.GetEntityByClassname("Department")));
    }
    [Fact]
    public void T13_EmployeeWorkloadIsRichTypeTest()
    {
        EnsureConstraint("Person", "Workload", "INTEGER");
        Assert.Equal("EmploymentPercentage", typeof(Employee).GetProperty("Workload")?.PropertyType.Name);
    }
    // DISCRIMINATOR TESTS
    [Fact]
    public void T14_PersonHasDiscriminatorTypeTest()
    {
        using var db = GetEmptyDbContext();
        Assert.Equal("PersonType", db.Model.GetEntityByClassname("Person").GetDiscriminatorPropertyName());
    }
    // CONVERTER TESTS
    [Fact]
    public void T15_ApplicationInterviewRatingHasCorrectValuesTest()
    {
        EnsureConstraint("ApplicationInterview", "Rating", "TEXT");
        using var db = GetEmptyDbContext();
        var converter = db.Model.GetEntityByClassname("ApplicationInterview").GetProperty("Rating").GetValueConverter();
        Assert.NotNull(converter);
        Assert.True(converter.ConvertFromProvider("AA")?.GetType()?.Name == "PerformanceRating");
        Assert.True(converter.ConvertFromProvider("A")?.GetType()?.Name == "PerformanceRating");
        Assert.True(converter.ConvertFromProvider("B")?.GetType()?.Name == "PerformanceRating");
        Assert.True(converter.ConvertFromProvider("C")?.GetType()?.Name == "PerformanceRating");
    }
    // SALARYRANGE TESTS
    [Fact]
    public void T16_SalaryRangeThrowsArgumentExceptionWhenInvalidArgumentsTest()
    {
        var type = typeof(SalaryRange);
        Assert.True(type.GetProperty("Max")?.PropertyType == typeof(decimal));
        Assert.True(type.GetProperty("Min")?.PropertyType == typeof(decimal));
        var ex = Assert.Throws<TargetInvocationException>(() => Activator.CreateInstance(type, 200M, 100M));
        Assert.True(ex.InnerException?.GetType().IsAssignableTo(typeof(ArgumentException)));
    }
    [Fact]
    public void T17_EmploymentPercentageThrowsArgumentExceptionWhenInvalidArgumentsTest()
    {
        var type = typeof(EmploymentPercentage);
        Assert.True(type.GetProperty("Value")?.PropertyType == typeof(int));
        var ex = Assert.Throws<TargetInvocationException>(() => Activator.CreateInstance(type, -1));
        Assert.True(ex.InnerException?.GetType().IsAssignableTo(typeof(ArgumentException)));
        ex = Assert.Throws<TargetInvocationException>(() => Activator.CreateInstance(type, 101));
        Assert.True(ex.InnerException?.GetType().IsAssignableTo(typeof(ArgumentException)));
    }

    private JobApplicationContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new JobApplicationContext(options);
        db.Database.EnsureCreated();
        return db;
    }

    private void InsertRowShouldFail(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(true, foreignKeyCheck, commandsTexts);
    private void InsertRowShouldFail(params string[] commandsTexts) => InsertRow(true, true, commandsTexts);
    private void InsertRow(params string[] commandsTexts) => InsertRow(false, true, commandsTexts);
    private void InsertRow(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(false, foreignKeyCheck, commandsTexts);
    private void InsertRow(bool shouldFail, bool foreignKeyCheck, params string[] commandsTexts)
    {
        using var db = GetEmptyDbContext();
        bool failed = false;
        using (var command = db.Database.GetDbConnection().CreateCommand())
        {
            command.CommandText = $"PRAGMA foreign_keys = {(foreignKeyCheck ? 1 : 0)}";
            db.Database.OpenConnection();
            command.ExecuteNonQuery();
        }

        foreach (var commandText in commandsTexts)
        {
            using var command = db.Database.GetDbConnection().CreateCommand();
            command.CommandText = commandText;
            db.Database.OpenConnection();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (SqliteException e)
            {
                failed = true;
                if (!shouldFail)
                    Assert.Fail($"Query failed: {commandText} with error {e.InnerException?.Message ?? e.Message}");
            }
        }
        if (shouldFail && !failed)
            Assert.Fail($"Query should fail, but it didn't. {string.Join(Environment.NewLine, commandsTexts)}");
    }

    private void EnsureConstraint(string table, string column, string type, bool isPk = false)
    {
        using var db = GetEmptyDbContext();
        using var cmd = db.Database.GetDbConnection().CreateCommand();
        cmd.CommandText = $"PRAGMA table_info({table})";
        db.Database.OpenConnection();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string columnName = reader.GetString(1);
            string columnType = reader.GetString(2);
            bool columnPk = reader.GetBoolean(5);
            if (columnName.Equals(column, StringComparison.OrdinalIgnoreCase))
            {
                Assert.True(columnType == type, $"Wrong datatype for {table}.{column}. Expected: {type}, given: {columnType}.");
                Assert.True(columnPk == isPk, $"Wrong primary key constraint {table}.{column}. Expected: {isPk}, given: {columnPk}.");
                return;
            }
        }
        Assert.Fail($"Column {table}.{column} not found.");
    }
}

public static class IModelExtensions
{
    public static IEntityType GetEntityByClassname(this IModel model, string name) =>
        model.GetEntityTypes().FirstOrDefault(t => t.ClrType.Name == name) ?? throw new ArgumentException($"Entity {name} not found in Model.");
}
