﻿using Microsoft.EntityFrameworkCore;
using Plf5aaif.Application.Model;
using System;

namespace Plf5aaif.Application.Infrastructure;

public class JobApplicationContext : DbContext
{
    // TODO: Add your DbSets

    public JobApplicationContext(DbContextOptions opt) : base(opt)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // TODO: Add your model configuration.
    }
}
