namespace Plf5aaif.Application.Model;

public class EmploymentPercentage
{
    // TODO: Add your implementation
}
