namespace Plf5aaif.Application.Model;

public class SalaryRange
{
    // TODO: Add your implementation
}
