namespace Plf5aaif.Application.Model;

public class JobApplication
{
    // TODO: Add your implementation
}
