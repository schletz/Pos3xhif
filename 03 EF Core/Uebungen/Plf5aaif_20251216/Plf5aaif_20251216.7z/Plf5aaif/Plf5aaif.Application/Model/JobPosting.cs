namespace Plf5aaif.Application.Model;

public class JobPosting
{
    // TODO: Add your implementation
}
