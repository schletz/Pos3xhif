namespace Plf5aaif.Application.Model;

public class Candidate : Person
{
    // TODO: Add your implementation
}
