namespace Plf5aaif.Application.Model;

public abstract class Person
{
    // TODO: Add your implementation
}
