﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace Plf5aaif.Application.Model;

public class ApplicationInterview
{
    // TODO: Add your implementation
}
