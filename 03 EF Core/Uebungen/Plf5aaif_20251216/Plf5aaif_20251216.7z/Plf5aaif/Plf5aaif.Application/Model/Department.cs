namespace Plf5aaif.Application.Model;

public class Department
{
    // TODO: Add your implementation
}
