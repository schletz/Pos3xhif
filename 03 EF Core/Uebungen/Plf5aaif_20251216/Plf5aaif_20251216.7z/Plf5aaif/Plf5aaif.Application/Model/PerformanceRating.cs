namespace Plf5aaif.Application.Model;

public enum PerformanceRating
{
    // TODO: Add your implementation
}
