namespace Plf5aaif.Application.Model;

public class OfficeLocation
{
    // TODO: Add your implementation
}
