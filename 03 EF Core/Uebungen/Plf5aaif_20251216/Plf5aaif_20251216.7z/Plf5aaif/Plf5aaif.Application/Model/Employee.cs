namespace Plf5aaif.Application.Model;

public class Employee : Person
{
    // TODO: Add your implementation
}
