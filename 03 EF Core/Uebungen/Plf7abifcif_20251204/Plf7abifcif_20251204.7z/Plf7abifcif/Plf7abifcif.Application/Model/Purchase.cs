﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Purchase
{
    // TODO: Add your implementation
}
