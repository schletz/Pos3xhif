﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Car : Vehicle
{
   // TODO: Add your implementation
}
