﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public abstract class Vehicle
{
    // TODO: Add your implementation
}
