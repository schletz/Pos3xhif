﻿using Microsoft.EntityFrameworkCore;

namespace Plf7abifcif.Application.Infrastructure;

public class StickerContext : DbContext
{
    // TODO: Add your DbSets

    public StickerContext(DbContextOptions opt) : base(opt)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // TODO: Add config
    }
}
