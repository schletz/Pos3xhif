﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Plf7abifcif.Application.Infrastructure;
using System;
using System.Diagnostics;

namespace Plf7abifcif.Test;

public class StickerContextTests
{
    private StickerContext GetDatabase()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();

        var opt = new DbContextOptionsBuilder()
            .UseSqlite(connection)  // Keep connection open (only needed with SQLite in memory db)
                                    //.UseSqlServer("Server=127.0.0.1;Database=Stickers;User Id=sa;Password=SqlServer2019;TrustServerCertificate=true")
            .LogTo(message => Debug.WriteLine(message), Microsoft.Extensions.Logging.LogLevel.Information)
            .EnableSensitiveDataLogging()
            .Options;
        var db = new StickerContext(opt);
        Debug.WriteLine(db.Database.GenerateCreateScript());
        db.Database.EnsureDeleted();
        db.Database.EnsureCreated();
        return db;
    }

    [Fact]
    public void T00_CreateDatabaseSuccessTest()
    {
        using var db = GetDatabase();
        Assert.True(db.Database.CanConnect());
    }

    [Fact]
    public void T01_AddPurchaseWithPaymentReceiptTest()
    {
        // TODO: Add your implementation
        throw new NotImplementedException();
    }
    [Fact]
    public void T02_LicensePlateNumberThrowsStickerExceptionIfNumberIsNotValidTest()
    {
        // TODO: Add your implementation
        throw new NotImplementedException();
    }
    [Fact]
    public void T03_LicensePlateAndRegistrationCountryThrowsExceptionWhenDuplicateTest()
    {
        // TODO: Add your implementation
        throw new NotImplementedException();
    }
    [Fact]
    public void T04_DiscriminatorInVehicleHasRightValuesTest()
    {
        // TODO: Add your implementation
        throw new NotImplementedException();
    }
}