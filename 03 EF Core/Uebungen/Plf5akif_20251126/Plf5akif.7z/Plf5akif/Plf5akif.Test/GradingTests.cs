﻿// *************************************************************************************************
// Grading tests for example.
// DO NOT TOUCH
// *************************************************************************************************
using Plf5akif.Application.Infrastructure;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System;
using System.Diagnostics;
using System.Linq;

namespace Plf5akif.Test;

public class GradingTests
{
    [Fact]
    public void T00_CanCreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
        string createScript = db.Database.GenerateCreateScript();
        Debug.Write(createScript);

        using var command = db.Database.GetDbConnection().CreateCommand();
        command.CommandText = $"SELECT COUNT(*) FROM sqlite_master WHERE type='table';";
        db.Database.OpenConnection();
        var result = (long?)command.ExecuteScalar();
        Assert.True(result >= 3, $"Less than 3 tables found. Check your DbSets & mappings.");
    }

    [Fact]
    public void T00_SchemaTest() => InsertRow(
        "INSERT INTO Doctor (Firstname, Lastname, Email) VALUES ('first', 'last', 'x@y.at')",
        "INSERT INTO Patient (Firstname, Lastname, InsuranceNumber, Mobile) VALUES ('first', 'last', '1234567890', null)",
        "INSERT INTO Appointment (Date, Created, PatientId) VALUES ('2025-12-02', '2025-11-24T13:00:00', 1)",
        "INSERT INTO AppointmentState (AppointmentId, Created, Type, DoctorId, PlannedSlot_Start, PlannedSlot_End, Infotext) VALUES (1, '2025-11-24T13:00:00', 'Confirmed', 1, '13:00:00', '14:00:00', null)"
        );

    [Fact]
    public void T01_InsertDoctorTest() => InsertRow(
        "INSERT INTO Doctor (Firstname, Lastname, Email) VALUES ('first', 'last', 'x@y.at')");
    [Fact]
    public void T02_InsertPatientTest() => InsertRow(
        "INSERT INTO Patient (Firstname, Lastname, InsuranceNumber, Mobile) VALUES ('first', 'last', '1234567890', null)");
    [Fact]
    public void T03_InsertAppointmentTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO Appointment (Date, Created, PatientId) VALUES ('2025-12-02', '2025-11-24T13:00:00', 1)");
    [Fact]
    public void T04_InsertAppointmentStateTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO AppointmentState (AppointmentId, Created, Type, DoctorId) VALUES (1, '2025-11-24T13:00:00', '', 1)");
    [Fact]
    public void T05_InsertConfirmedAppointmentStateTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO AppointmentState (AppointmentId, Created, Type, DoctorId, PlannedSlot_Start, PlannedSlot_End, Infotext) VALUES (1, '2025-11-24T13:00:00', 'Confirmed', 1, '13:00:00', '14:00:00', null)");
    [Fact]
    public void T06_InsertCancelledAppointmentStateTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO AppointmentState (AppointmentId, Created, Type) VALUES (1, '2025-11-24T13:00:00', 'Cancelled')");

    // UNIQUE TESTS
    [Fact]
    public void T07_DoctorEmailIsUniqueTest()
    {
        InsertRow(foreignKeyCheck: false,
            "INSERT INTO Doctor (Firstname, Lastname, Email) VALUES ('first', 'last', 'x@y.at')");
        InsertRowShouldFail(foreignKeyCheck: false,
            "INSERT INTO Doctor (Firstname, Lastname, Email) VALUES ('first', 'last', 'x@y.at')",
            "INSERT INTO Doctor (Firstname, Lastname, Email) VALUES ('first2', 'last2', 'x@y.at')");
    }

    [Fact]
    public void T08_AppointmentDateAndPatientIsUniqueTest()
    {
        InsertRow(foreignKeyCheck: false,
            "INSERT INTO Appointment (Date, Created, PatientId) VALUES ('2025-12-02', '2025-11-24T13:00:00', 1)");
        InsertRowShouldFail(foreignKeyCheck: false,
            "INSERT INTO Appointment (Date, Created, PatientId) VALUES ('2025-12-02', '2025-11-24T13:00:00', 1)",
            "INSERT INTO Appointment (Date, Created, PatientId) VALUES ('2025-12-02', '2025-11-24T14:00:00', 1)");
    }

    // MODEL CONFIG TESTS
    [Fact]
    public void T09_AppiontmentStateHasDiscriminatorTypeTest()
    {
        using var db = GetEmptyDbContext();
        Assert.Equal("Type", db.Model.GetEntityByClassname("AppointmentState").GetDiscriminatorPropertyName());
    }
    [Fact]
    public void T10_DiscriminatorValuesForAppointmentStateAreCorrectTest()
    {
        using var db = GetEmptyDbContext();
        Assert.Equal("Confirmed", db.Model.GetEntityByClassname("ConfirmedAppointmentState").GetDiscriminatorValue());
        Assert.Equal("Cancelled", db.Model.GetEntityByClassname("CancelledAppointmentState").GetDiscriminatorValue());
    }
    [Fact]
    public void T11_TimeSlotIsValueObjectTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(db.Model.GetEntityByClassname("TimeSlot").IsInOwnershipPath(db.Model.GetEntityByClassname("ConfirmedAppointmentState")));
    }
    [Fact]
    public void T12_PhoneNumberIsRichTypeTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(
            db.Model.GetEntityByClassname("Patient").GetProperty("Mobile").GetValueConverter()?.ModelClrType.Name == "PhoneNumber",
            "PhoneNumber has no value converter. Did you fake it with a string or an entity??? 😠");
    }
    [Fact]
    public void T13_InsuranceNumberIsRichTypeTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(
            db.Model.GetEntityByClassname("Patient").GetProperty("InsuranceNumber").GetValueConverter()?.ModelClrType.Name == "InsuranceNumber",
            "InsuranceNumber has no value converter. Did you fake it with a string or an entity??? 😠");
    }

    private AppointmentContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new AppointmentContext(options);
        db.Database.EnsureCreated();
        return db;
    }

    private void InsertRowShouldFail(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(true, foreignKeyCheck, commandsTexts);
    private void InsertRowShouldFail(params string[] commandsTexts) => InsertRow(true, true, commandsTexts);
    private void InsertRow(params string[] commandsTexts) => InsertRow(false, true, commandsTexts);
    private void InsertRow(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(false, foreignKeyCheck, commandsTexts);
    private void InsertRow(bool shouldFail, bool foreignKeyCheck, params string[] commandsTexts)
    {
        using var db = GetEmptyDbContext();
        bool failed = false;
        using (var command = db.Database.GetDbConnection().CreateCommand())
        {
            command.CommandText = $"PRAGMA foreign_keys = {(foreignKeyCheck ? 1 : 0)}";
            db.Database.OpenConnection();
            command.ExecuteNonQuery();
        }

        foreach (var commandText in commandsTexts)
        {
            using var command = db.Database.GetDbConnection().CreateCommand();
            command.CommandText = commandText;
            db.Database.OpenConnection();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (SqliteException e)
            {
                failed = true;
                if (!shouldFail)
                    Assert.Fail($"Query failed: {commandText} with error {e.InnerException?.Message ?? e.Message}");
            }
        }
        if (shouldFail && !failed)
            Assert.Fail($"Query should fail, but it didn't. {string.Join(Environment.NewLine, commandsTexts)}");
    }

    private void EnsureConstraint(string table, string column, string type, bool isPk = false)
    {
        using var db = GetEmptyDbContext();
        using var cmd = db.Database.GetDbConnection().CreateCommand();
        cmd.CommandText = $"PRAGMA table_info({table})";
        db.Database.OpenConnection();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string columnName = reader.GetString(1);
            string columnType = reader.GetString(2);
            bool columnPk = reader.GetBoolean(5);
            if (columnName.Equals(column, StringComparison.OrdinalIgnoreCase))
            {
                Assert.True(columnType == type, $"Wrong datatype for {table}.{column}. Expected: {type}, given: {columnType}.");
                Assert.True(columnPk == isPk, $"Wrong primary key constraint {table}.{column}. Expected: {isPk}, given: {columnPk}.");
                return;
            }
        }
        Assert.Fail($"Column {table}.{column} not found.");
    }
}

public static class IModelExtensions
{
    public static IEntityType GetEntityByClassname(this IModel model, string name) =>
        model.GetEntityTypes().FirstOrDefault(t => t.ClrType.Name == name) ?? throw new ArgumentException($"Entity {name} not found in Model.");
}
