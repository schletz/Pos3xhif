﻿using Plf5akif.Application.Infrastructure;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using System;
using System.Diagnostics;

namespace Plf5akif.Test;

public class AppointmentContextTests
{
    private AppointmentContext GetDatabase()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();

        var opt = new DbContextOptionsBuilder()
            .UseSqlite(connection)  // Keep connection open (only needed with SQLite in memory db)
            .LogTo(message => Debug.WriteLine(message), Microsoft.Extensions.Logging.LogLevel.Information)
            .EnableSensitiveDataLogging()
            .Options;
        var db = new AppointmentContext(opt);
        Debug.WriteLine(db.Database.GenerateCreateScript());
        db.Database.EnsureDeleted();
        db.Database.EnsureCreated();
        return db;
    }

    [Fact]
    public void CreateDatabaseSuccessTest()
    {
        using var db = GetDatabase();
        Assert.True(db.Database.CanConnect());
    }

    [Fact]
    public void AddPatientTest()
    {
        throw new NotImplementedException();
    }

    [Fact]
    public void InsuranceNummerNotValidTest()
    {
        throw new NotImplementedException();
    }

    [Fact]
    public void AddAppointmentWithStateConfirmedTest()
    {
        throw new NotImplementedException();
    }

    [Fact]
    public void DoctorEmailThrowsDbUpdateExceptionIfNotUniqueTest()
    {
        throw new NotImplementedException();
    }
}