﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class CancelledAppointmentState : AppointmentState
{
    // TODO: Implementierung der Klasse
}
