﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class InsuranceNumber
{
    // TODO: Implementierung der Klasse
}
