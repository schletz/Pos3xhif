﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class ConfirmedAppointmentState : AppointmentState
{
    // TODO: Implementierung der Klasse
}
