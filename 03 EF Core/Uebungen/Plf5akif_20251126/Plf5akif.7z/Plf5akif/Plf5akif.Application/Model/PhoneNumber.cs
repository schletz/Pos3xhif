﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class PhoneNumber
{
    // TODO: Implementierung der Klasse
}
