﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public abstract class AppointmentState
{    
    // TODO: Implementierung der Klasse
}
