﻿namespace SPG_Fachtheorie.Aufgabe1.Model;

public class Patient
{
    // TODO: Implementierung der Klasse
}
