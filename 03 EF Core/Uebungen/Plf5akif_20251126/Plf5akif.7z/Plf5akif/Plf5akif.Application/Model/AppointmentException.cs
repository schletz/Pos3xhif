﻿using System;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    [Serializable]
    internal class AppointmentException : Exception
    {
        public AppointmentException()
        {
        }

        public AppointmentException(string? message) : base(message)
        {
        }

        public AppointmentException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}