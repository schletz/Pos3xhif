﻿using Microsoft.EntityFrameworkCore;

namespace Plf5akif.Application.Infrastructure;

public class AppointmentContext : DbContext
{
    // TODO: Füge hier die DbSets ein.

    public AppointmentContext(DbContextOptions opt) : base(opt)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // TODO: Füge hier die Modellkonfiguration ein.
    }
}
