﻿namespace Plf5caif.Application.Model;

public class VersionNumber
{
    // TODO: Add your implementation.
}
