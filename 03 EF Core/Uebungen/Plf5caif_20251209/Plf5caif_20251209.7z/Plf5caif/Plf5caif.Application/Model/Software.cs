﻿namespace Plf5caif.Application.Model;

public class Software
{
    // TODO: Add your implementation.
}
