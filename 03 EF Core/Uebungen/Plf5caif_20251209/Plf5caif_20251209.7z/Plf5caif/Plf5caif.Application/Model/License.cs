﻿namespace Plf5caif.Application.Model;

public class License
{
    // TODO: Add your implementation.
}
