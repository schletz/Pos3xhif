﻿namespace Plf5caif.Application.Model;

public enum Activated
{
    // TODO: Add your implementation.
}
