﻿namespace Plf5caif.Application.Model;
public class UserLicense : License
{
    // TODO: Add your implementation.
}
