﻿namespace Plf5caif.Application.Model;

public class Person
{
    // TODO: Add your implementation.
}
