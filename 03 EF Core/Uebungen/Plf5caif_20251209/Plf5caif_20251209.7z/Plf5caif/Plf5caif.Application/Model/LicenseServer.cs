﻿namespace Plf5caif.Application.Model;

public class LicenseServer
{
    // TODO: Add your implementation.
}
