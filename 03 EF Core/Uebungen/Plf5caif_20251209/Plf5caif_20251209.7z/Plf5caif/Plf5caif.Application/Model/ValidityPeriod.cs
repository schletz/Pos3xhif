﻿namespace Plf5caif.Application.Model;

public class ValidityPeriod
{
    // TODO: Add your implementation.
}
