﻿namespace Plf5caif.Application.Model;

public class User
{
    // TODO: Add your implementation.
}
