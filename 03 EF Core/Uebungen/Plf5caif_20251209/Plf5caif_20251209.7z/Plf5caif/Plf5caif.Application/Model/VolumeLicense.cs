﻿namespace Plf5caif.Application.Model;

public class VolumeLicense : License
{
    // TODO: Add your implementation.
}