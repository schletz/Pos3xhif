﻿using Microsoft.EntityFrameworkCore;

namespace Plf5caif.Application.Infrastructure;

public class LicenseContext : DbContext
{
    // TODO: Add your DbSets.

    public LicenseContext(DbContextOptions opt) : base(opt)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // TODO: Add your configuration.
    }
}
