﻿// *************************************************************************************************
// Grading tests for example.
// DO NOT TOUCH
// *************************************************************************************************
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Plf5caif.Application.Infrastructure;
using Plf5caif.Application.Model;
using System;
using System.Diagnostics;
using System.Linq;

namespace Plf5caif.Test;

public class GradingTests
{
    [Fact]
    public void T00_CanCreateDatabaseTest()
    {
        using var db = GetEmptyDbContext();
        string createScript = db.Database.GenerateCreateScript();
        Debug.Write(createScript);

        using var command = db.Database.GetDbConnection().CreateCommand();
        command.CommandText = $"SELECT COUNT(*) FROM sqlite_master WHERE type='table';";
        db.Database.OpenConnection();
        var result = (long?)command.ExecuteScalar();
        Assert.True(result >= 3, $"Less than 3 tables found. Check your DbSets & mappings.");
    }

    [Fact]
    public void T00_SchemaTest() => InsertRow(
        "INSERT INTO Person (Firstname, Lastname) VALUES ('first', 'last');",
        "INSERT INTO Software (Name, Version, Vendor) VALUES ('Adobe Creative Cloud', '16.5.1', 'bmbwf');",
        "INSERT INTO User (Accountname, LastLogin, PersonId) VALUES ('ABC123456', NULL, 1);",
        "INSERT INTO LicenseServer (Url, Port, SoftwareId) VALUES ('activate.spengergasse.at', 8080, 1);",
        "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt, Key) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense', 1, '2026-01-03T12:00:00Z', NULL);");

    
    // MODEL TESTS
    [Fact]
    public void T01_InsertPersonTest() => InsertRow(
        "INSERT INTO Person (Firstname, Lastname) VALUES ('first', 'last');");
    [Fact]
    public void T02_InsertSoftwareTest() => InsertRow(
        "INSERT INTO Software (Name, Version, Vendor) VALUES ('Adobe Creative Cloud', '16.5.1', 'bmbwf');");
    [Fact]
    public void T03_InsertUserTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO User (Accountname, LastLogin, PersonId) VALUES ('ABC123456', NULL, 1);");
    [Fact]
    public void T04_InsertLicenseServerTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO LicenseServer (Url, Port, SoftwareId) VALUES ('activate.spengergasse.at', 8080, 1);");
    [Fact]
    public void T05_InsertLicenseTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense');");
    [Fact]
    public void T06_InsertUserLicenseTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense', 1, '2026-01-03T12:00:00Z');");
    [Fact]
    public void T07_InsertVolumeLicenseTest() => InsertRow(foreignKeyCheck: false,
        "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, Key) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'VolumeLicense', '12345-12');");

    // 1:1 TESTS
    [Fact]
    public void T08_PersonAndUserIsOneToOneTest()
    {
        using var db = GetEmptyDbContext();
        var principalEntity = db.Model.GetEntityByClassname("Person");
        var dependentEntity = db.Model.GetEntityByClassname("User");
        var fk = dependentEntity.FindDeclaredNavigation("Person")?.ForeignKey;
        Assert.NotNull(fk);
        Assert.True(fk.IsUnique);
        Assert.True(fk.DeclaringEntityType == dependentEntity);
        Assert.True(fk.PrincipalEntityType == principalEntity);
    }

    // UNIQUE CONSTRAINT TESTS
    [Fact]
    public void T09_UserAccountnameIsUniqueTest()
    {
        InsertRow(foreignKeyCheck: false,
            "INSERT INTO User (Accountname, LastLogin, PersonId) VALUES ('ABC123456', '2025-12-06T14:12:31Z', 1);");
        InsertRowShouldFail(foreignKeyCheck: false,
            "INSERT INTO User (Accountname, LastLogin, PersonId) VALUES ('ABC123456', '2025-12-06T14:12:31Z', 1);",
            "INSERT INTO User (Accountname, LastLogin, PersonId) VALUES ('ABC123456', '2025-12-07T14:12:31Z', 2);");
    }
    [Fact]
    public void T10_UserLicenseSoftwareIdAndUserIdIsUniqueTest()
    {
        InsertRow(foreignKeyCheck: false,
             "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense', 1, '2026-01-03T12:00:00Z');",
             "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense', 2, '2026-01-03T12:00:00Z');",
             "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt) VALUES (2, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense', 1, '2026-01-03T12:00:00Z');");
        InsertRowShouldFail(foreignKeyCheck: false,
             "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt) VALUES (1, '2026-01-01T12:00:00Z', '2027-01-01T12:00:00Z', 'A', 'UserLicense', 1, '2026-01-03T12:00:00Z');",
             "INSERT INTO License (SoftwareId, Validity_From, Validity_To, Activated, LicenseType, UserId, IssuedAt) VALUES (1, '2026-02-01T12:00:00Z', '2027-02-01T12:00:00Z', 'I', 'UserLicense', 1, '2026-02-03T12:00:00Z');");
    }

    // VALUE OBJECT AND RICH TYPE TESTS
    [Fact]
    public void T11_LicenseValidityIsValueObjectTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(db.Model.GetEntityByClassname("ValidityPeriod").IsInOwnershipPath(db.Model.GetEntityByClassname("License")));
    }
    [Fact]
    public void T12_SoftwareLicenseServerIsValueObjectTest()
    {
        using var db = GetEmptyDbContext();
        Assert.True(db.Model.GetEntityByClassname("LicenseServer").IsInOwnershipPath(db.Model.GetEntityByClassname("Software")));
    }
    [Fact]
    public void T13_SoftwareVersionNumberIsRichTypeTest()
    {
        EnsureConstraint("Software", "Version", "TEXT");
        Assert.Equal("VersionNumber", typeof(Software).GetProperty("Version")?.PropertyType.Name);
    }
    // DISCRIMINATOR TESTS
    [Fact]
    public void T14_LicenseHasDiscriminatorTypeTest()
    {
        using var db = GetEmptyDbContext();
        Assert.Equal("LicenseType", db.Model.GetEntityByClassname("License").GetDiscriminatorPropertyName());
    }
    // CONVERTER TESTS
    [Fact]
    public void T15_LicenseActivatedHasCorrectValuesTest()
    {
        EnsureConstraint("License", "Activated", "TEXT");
        using var db = GetEmptyDbContext();
        var converter = db.Model.GetEntityByClassname("License").GetProperty("Activated").GetValueConverter();
        Assert.NotNull(converter);
        Assert.True(converter.ConvertFromProvider("A")?.GetType()?.Name == "Activated");
        Assert.True(converter.ConvertFromProvider("I")?.GetType()?.Name == "Activated");
    }
    [Fact]
    public void T16_VersionNumberCanReadVersionTest()
    {
        using var db = GetEmptyDbContext();
        var converter = db.Model.GetEntityByClassname("Software").GetProperty("Version").GetValueConverter();
        Assert.NotNull(converter);
        Assert.True(converter.ConvertFromProvider("1.2")?.ToString() == "1.2");
        Assert.True(converter.ConvertFromProvider("1.2.3")?.ToString() == "1.2.3");
    }
    // VERSIONNUMBER TESTS
    [Fact]
    public void T17_VersionNumberWorksTest()
    {
        var type = typeof(VersionNumber);
        Assert.True(type.GetProperty("Major")?.PropertyType == typeof(int));
        Assert.True(type.GetProperty("Minor")?.PropertyType == typeof(int));
        Assert.True(Activator.CreateInstance(type, 1, 2, null)?.ToString() == "1.2", "new VersionNumber(1,2,null).ToString() does not produce 1.2");
        Assert.True(Activator.CreateInstance(type, 1, 2, 3)?.ToString() == "1.2.3",  "new VersionNumber(1,2,3).ToString() does not produce 1.2.3");
        Assert.True(Activator.CreateInstance(type, "1.0")?.ToString() == "1.0",     @"new VersionNumber(""1.0"").ToString() does not produce 1.0");
        Assert.True(Activator.CreateInstance(type, "1.2.3")?.ToString() == "1.2.3", @"new VersionNumber(""1.2.3"").ToString() does not produce 1.2.3");
    }

    private LicenseContext GetEmptyDbContext()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder()
            .UseSqlite(connection)
            .Options;

        var db = new LicenseContext(options);
        db.Database.EnsureCreated();
        return db;
    }

    private void InsertRowShouldFail(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(true, foreignKeyCheck, commandsTexts);
    private void InsertRowShouldFail(params string[] commandsTexts) => InsertRow(true, true, commandsTexts);
    private void InsertRow(params string[] commandsTexts) => InsertRow(false, true, commandsTexts);
    private void InsertRow(bool foreignKeyCheck, params string[] commandsTexts) => InsertRow(false, foreignKeyCheck, commandsTexts);
    private void InsertRow(bool shouldFail, bool foreignKeyCheck, params string[] commandsTexts)
    {
        using var db = GetEmptyDbContext();
        bool failed = false;
        using (var command = db.Database.GetDbConnection().CreateCommand())
        {
            command.CommandText = $"PRAGMA foreign_keys = {(foreignKeyCheck ? 1 : 0)}";
            db.Database.OpenConnection();
            command.ExecuteNonQuery();
        }

        foreach (var commandText in commandsTexts)
        {
            using var command = db.Database.GetDbConnection().CreateCommand();
            command.CommandText = commandText;
            db.Database.OpenConnection();
            try
            {
                command.ExecuteNonQuery();
            }
            catch (SqliteException e)
            {
                failed = true;
                if (!shouldFail)
                    Assert.Fail($"Query failed: {commandText} with error {e.InnerException?.Message ?? e.Message}");
            }
        }
        if (shouldFail && !failed)
            Assert.Fail($"Query should fail, but it didn't. {string.Join(Environment.NewLine, commandsTexts)}");
    }

    private void EnsureConstraint(string table, string column, string type, bool isPk = false)
    {
        using var db = GetEmptyDbContext();
        using var cmd = db.Database.GetDbConnection().CreateCommand();
        cmd.CommandText = $"PRAGMA table_info({table})";
        db.Database.OpenConnection();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            string columnName = reader.GetString(1);
            string columnType = reader.GetString(2);
            bool columnPk = reader.GetBoolean(5);
            if (columnName.Equals(column, StringComparison.OrdinalIgnoreCase))
            {
                Assert.True(columnType == type, $"Wrong datatype for {table}.{column}. Expected: {type}, given: {columnType}.");
                Assert.True(columnPk == isPk, $"Wrong primary key constraint {table}.{column}. Expected: {isPk}, given: {columnPk}.");
                return;
            }
        }
        Assert.Fail($"Column {table}.{column} not found.");
    }
}

public static class IModelExtensions
{
    public static IEntityType GetEntityByClassname(this IModel model, string name) =>
        model.GetEntityTypes().FirstOrDefault(t => t.ClrType.Name == name) ?? throw new ArgumentException($"Entity {name} not found in Model.");
}
