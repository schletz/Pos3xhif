﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Plf5caif.Application.Infrastructure;
using Plf5caif.Application.Model;
using System;
using System.Diagnostics;
using System.Linq;

namespace Plf5caif.Test;

public class LicenseContextTests
{
    private LicenseContext GetDatabase()
    {
        var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();

        var opt = new DbContextOptionsBuilder()
            .UseSqlite(connection)  // Keep connection open (only needed with SQLite in memory db)
            //.UseSqlServer("Server=127.0.0.1;Database=Licenses;User Id=sa;Password=SqlServer2019;TrustServerCertificate=true")
            .LogTo(message => Debug.WriteLine(message), Microsoft.Extensions.Logging.LogLevel.Information)
            .EnableSensitiveDataLogging()
            .Options;
        var db = new LicenseContext(opt);
        Debug.WriteLine(db.Database.GenerateCreateScript());
        db.Database.EnsureDeleted();
        db.Database.EnsureCreated();
        return db;
    }

    [Fact]
    public void T00_CreateDatabaseSuccessTest()
    {
        using var db = GetDatabase();
        Assert.True(db.Database.CanConnect());
    }

    [Fact]
    public void T01_InsertSoftwareWithUserLicenceTest()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    [Fact]
    public void T02_UserLicenceUserAndSoftwareIsUniqueTest()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    [Fact]
    public void T03_AddSoftwareWithLicenceServersTest()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

    [Fact]
    public void T04_VersionNumberFromNumericArgumentsReturnsCorrentStringTest()
    {
        // TODO: Add your implementation.
        throw new NotImplementedException();
    }

}