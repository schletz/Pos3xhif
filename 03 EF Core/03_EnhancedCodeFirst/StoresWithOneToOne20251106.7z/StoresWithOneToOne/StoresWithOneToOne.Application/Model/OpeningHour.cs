﻿namespace StoreManager.Application.Model;

public class OpeningHour
{
    // TODO: Add your implementation
}

