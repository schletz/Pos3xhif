﻿namespace StoreManager.Application.Model;

public class ProductDetail
{
    // TODO: Add your implementation
}

