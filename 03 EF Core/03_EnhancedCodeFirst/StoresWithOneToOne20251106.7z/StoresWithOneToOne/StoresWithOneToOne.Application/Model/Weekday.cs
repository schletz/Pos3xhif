﻿namespace StoreManager.Application.Model;

public enum Weekday
{
    // TODO: Add your implementation
}

