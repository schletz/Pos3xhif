﻿namespace StoreManager.Application.Model;

public class Store
{
    // TODO: Add your implementation
}

