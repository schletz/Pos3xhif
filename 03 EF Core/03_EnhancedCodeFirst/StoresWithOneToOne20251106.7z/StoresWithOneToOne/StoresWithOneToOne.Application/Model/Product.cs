﻿namespace StoreManager.Application.Model;

public class Product
{
    // TODO: Add your implementation
}

