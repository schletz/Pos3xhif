﻿namespace StoreManager.Application.Model;

public class StoreDetail
{
    // TODO: Add your implementation
}

