﻿namespace StoreManager.Application.Model;

public class Offer
{
    // TODO: Add your implementation
}

