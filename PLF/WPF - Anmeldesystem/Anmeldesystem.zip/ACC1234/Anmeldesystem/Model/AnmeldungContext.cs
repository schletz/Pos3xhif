﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Documents;

namespace Anmeldesystem.Model
{
    public class AnmeldungContext : DbContext
    {
        DbSet<Anmeldung> Anmeldungen { get; set; }
        DbSet<Fach> Faecher { get; set; }
        DbSet<Klasse> Klassen { get; set; }
        DbSet<Schueler> Schueler { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=Anmeldungen.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }

        public void Seed()
        {
            var klassen = new List<Klasse> 
            {
                new Klasse { Name = "5AHIF" },
                new Klasse { Name = "5BHIF" },
                new Klasse { Name = "5CHIF" }
            };

            var schueler = new List<Schueler>
            {
                new Schueler { Vorname = "Vorname_5A_1", Zuname = "Zuname_5A_1", Klasse = klassen[0] },
                new Schueler { Vorname = "Vorname_5A_2", Zuname = "Zuname_5A_2", Klasse = klassen[0] },
                new Schueler { Vorname = "Vorname_5A_3", Zuname = "Zuname_5A_3", Klasse = klassen[0] },
                new Schueler { Vorname = "Vorname_5B_1", Zuname = "Zuname_5B_1", Klasse = klassen[1] },
                new Schueler { Vorname = "Vorname_5B_2", Zuname = "Zuname_5B_2", Klasse = klassen[1] },
                new Schueler { Vorname = "Vorname_5C_1", Zuname = "Zuname_5C_1", Klasse = klassen[2] },
            };

            var faecher = new List<Fach>
            {
                new Fach {Name = "AM"},
                new Fach {Name = "D"},
                new Fach {Name = "E"}
            };

            var anmeldungen = new List<Anmeldung>
            {
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,26,12,13,23), Fach = faecher[0], Schueler = schueler[0]},
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,26,13,14,24), Fach = faecher[1], Schueler = schueler[0]},
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,26,14,15,25), Fach = faecher[2], Schueler = schueler[1]},
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,28,15,16,26), Fach = faecher[0], Schueler = schueler[2]},
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,28,16,17,27), Fach = faecher[1], Schueler = schueler[2]},
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,28,17,18,28), Fach = faecher[2], Schueler = schueler[3]},
                new Anmeldung {Anmeldedatum = new DateTime(2020,4,28,18,19,29), Fach = faecher[0], Schueler = schueler[4]},
            };

            Klassen.AddRange(klassen);
            SaveChanges();
            Schueler.AddRange(schueler);
            SaveChanges();
            Faecher.AddRange(faecher);
            SaveChanges();
            Anmeldungen.AddRange(anmeldungen);
            SaveChanges();
        }
    }
}
