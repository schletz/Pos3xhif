﻿using System.Collections.Generic;

namespace Anmeldesystem.Model
{
    public class Schueler
    {
        public int SchuelerId { get; set; }
        public string Vorname { get; set; }
        public string Zuname { get; set; }
        public Klasse Klasse { get; set; }
        public List<Anmeldung> Anmeldungen { get; set; }
    }
}
