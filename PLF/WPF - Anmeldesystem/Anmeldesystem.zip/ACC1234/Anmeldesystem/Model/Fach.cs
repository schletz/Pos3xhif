﻿using System.Collections.Generic;

namespace Anmeldesystem.Model
{
    public class Fach
    {
        public string Name { get; set; }
        public List<Anmeldung> Anmeldungen { get; set; }
    }
}
