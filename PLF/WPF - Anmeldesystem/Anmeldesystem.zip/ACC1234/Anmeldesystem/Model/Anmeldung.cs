﻿using System;

namespace Anmeldesystem.Model
{
    public class Anmeldung
    {
        public int AnmeldungId { get; set; }
        public DateTime Anmeldedatum { get; set; }
        public Schueler Schueler { get; set; }
        public Fach Fach { get; set; }
    }
}
