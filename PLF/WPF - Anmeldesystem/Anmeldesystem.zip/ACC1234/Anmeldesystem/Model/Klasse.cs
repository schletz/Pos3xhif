﻿using System.Collections.Generic;

namespace Anmeldesystem.Model
{
    public class Klasse
    {
        public string Name { get; set; }
        public List<Schueler> Schueler { get; set; }
    }
}
